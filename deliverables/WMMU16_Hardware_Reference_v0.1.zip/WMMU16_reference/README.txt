WMMU16 v0.1 hardware reference package

The authoritative functional and CSR specification is the accompanying DOCX.
This is a proposed vendor-specific interface, not an industry standard ABI.

Files
  wmmu_model.py    Pure configuration validator and address lookup model.
  wmmu_lookup.sv   Synthesizable-style combinational lookup reference only.
  wmmu_regs.h      Register offsets, command/status enums and entry layout.
  tb_lookup.sv    Vector-driven address lookup simulation testbench.
  run_checks.py    Deterministic boundary/random differential tests.

Run
  python3 run_checks.py
Requires Python 3.10+, Icarus Verilog (iverilog and vvp), and clang or cc.

Scope
The SV module contains no MMIO registers, state machine, pipeline registers,
clock-domain crossings, fault latch, data completion tracker or DMA adapter.
Those blocks must implement the contracts in the specification. The test suite
checks only the provided validator/lookup/header; it is not full IP sign-off.
No synthesis area, timing, power, FPGA or silicon result is claimed.

Reference profile
16 fixed windows; unsigned 48-bit device VA; 48-bit node-local PA;
4-bit node ID; one trusted address space per isolation partition;
1..4096 byte contiguous read/write requests; no demand paging or TLB eviction.
