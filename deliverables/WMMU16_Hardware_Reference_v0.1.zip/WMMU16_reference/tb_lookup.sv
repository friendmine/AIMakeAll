module tb_lookup;
    logic [63:0] req_va, entry_va[0:15], entry_size[0:15], entry_pa[0:15], entry_attr[0:15];
    logic [31:0] req_len;
    logic [1:0] req_op;
    logic [15:0] node_mask;
    logic [3:0] status, target_node;
    logic [47:0] target_pa;
    logic [7:0] match_index;
    logic [3:0] exp_status, exp_node;
    logic [47:0] exp_pa;
    logic [7:0] exp_index;
    integer f, n, rc, total;
    string filename;
    wmmu_lookup dut(.*);
    initial begin
        if (!$value$plusargs("vectors=%s", filename)) $fatal(1,"missing vectors");
        f=$fopen(filename,"r");
        if (!f) $fatal(1,"cannot open vectors");
        rc=$fscanf(f,"%d",total);
        if (rc != 1) $fatal(1,"bad header");
        for(n=0;n<total;n=n+1) begin
            rc=$fscanf(f,"%h %h %h %h %h %h %h %h",node_mask,req_va,req_len,req_op,
                       exp_status,exp_node,exp_pa,exp_index);
            if (rc != 8) $fatal(1,"bad vector");
            for(integer i=0;i<16;i=i+1) begin
                rc=$fscanf(f,"%h %h %h %h",entry_va[i],entry_size[i],entry_pa[i],entry_attr[i]);
                if (rc != 4) $fatal(1,"bad entry");
            end
            #1;
            if ({status,target_node,target_pa,match_index} !== {exp_status,exp_node,exp_pa,exp_index})
                $fatal(1,"vector %0d got %h/%h/%h/%h expected %h/%h/%h/%h",n,
                 status,target_node,target_pa,match_index,exp_status,exp_node,exp_pa,exp_index);
        end
        $display("PASS %0d lookup vectors",total);
        $fclose(f); $finish;
    end
endmodule
