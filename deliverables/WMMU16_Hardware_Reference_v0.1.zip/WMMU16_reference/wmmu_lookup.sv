// WMMU16 v0.1 combinational reference datapath. NOT a complete MMU IP.
// Excludes registers, config validation, pipeline, fault FSM and DMA bridge.
module wmmu_lookup (
    input  logic [63:0] req_va,
    input  logic [31:0] req_len,
    input  logic [1:0]  req_op,
    input  logic [15:0] node_mask,
    input  logic [63:0] entry_va   [0:15],
    input  logic [63:0] entry_size [0:15],
    input  logic [63:0] entry_pa   [0:15],
    input  logic [63:0] entry_attr [0:15],
    output logic [3:0]  status,
    output logic [3:0]  target_node,
    output logic [47:0] target_pa,
    output logic [7:0]  match_index
);
    localparam logic [64:0] LIMIT = 65'h00001000000000000;
    integer hit_count;
    logic [3:0] selected;
    logic [63:0] offset, remaining;
    logic [64:0] phys_start, phys_end;
    logic [3:0] node;

    always_comb begin
        status = 0;
        target_node = 0;
        target_pa = 0;
        match_index = 8'hff;
        hit_count = 0;
        selected = 0;
        offset = 0;
        remaining = 0;
        phys_start = 0;
        phys_end = 0;
        node = 0;
        for (integer i=0; i<16; i=i+1) begin
            if (entry_attr[i][0] && req_va >= entry_va[i] &&
                (req_va - entry_va[i]) < entry_size[i]) begin
                hit_count = hit_count + 1;
                selected = 4'(i);
            end
        end
        if (req_va[63:48] != 0 || req_len == 0 || req_len > 4096 || req_op > 1)
            status = 1;
        else if (hit_count == 0)
            status = 2;
        else if (hit_count != 1)
            status = 3;
        else begin
            match_index = {4'b0, selected};
            offset = req_va - entry_va[selected];
            remaining = entry_size[selected] - offset;
            phys_start = {1'b0, entry_pa[selected]} + {1'b0, offset};
            phys_end = phys_start + {33'b0, req_len};
            node = entry_attr[selected][7:4];
            if ({32'b0, req_len} > remaining)
                status = 4;
            else if ((req_op == 0 && !entry_attr[selected][1]) ||
                     (req_op == 1 && !entry_attr[selected][2]))
                status = 5;
            else if (entry_pa[selected][63:48] != 0 || phys_end > LIMIT)
                status = 6;
            else if (!node_mask[node])
                status = 7;
            else begin
                target_node = node;
                target_pa = phys_start[47:0];
            end
        end
    end
endmodule
