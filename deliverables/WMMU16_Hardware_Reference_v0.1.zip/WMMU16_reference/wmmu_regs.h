#ifndef WMMU_REGS_H
#define WMMU_REGS_H
#include <stdint.h>
#include <stddef.h>
#define WMMU_ID_VALUE          UINT32_C(0x574d4d55)
#define WMMU_VERSION_VALUE     UINT32_C(0x00000001)
#define WMMU_ENTRY_COUNT       16u
#define WMMU_MAX_REQ           4096u
#define WMMU_REG_ID            0x000u
#define WMMU_REG_VERSION       0x004u
#define WMMU_REG_CAPS          0x008u
#define WMMU_REG_PARAMS        0x00cu
#define WMMU_REG_TOPO          0x010u
#define WMMU_REG_MAX_REQ        0x014u
#define WMMU_REG_CMD           0x018u
#define WMMU_REG_STATUS        0x01cu
#define WMMU_REG_CFG_GEN        0x020u
#define WMMU_REG_CFG_ERROR      0x024u
#define WMMU_REG_IRQ_EN         0x028u
#define WMMU_REG_IRQ_STATUS     0x02cu
#define WMMU_REG_COUNT_REQ      0x030u
#define WMMU_REG_COUNT_OK       0x034u
#define WMMU_REG_COUNT_FAULT    0x038u
#define WMMU_REG_COUNT_CANCEL   0x03cu
#define WMMU_REG_COUNT_LOCAL    0x040u
#define WMMU_REG_COUNT_REMOTE   0x044u
#define WMMU_REG_FAULT_INFO     0x080u
#define WMMU_REG_FAULT_REQ_ID   0x084u
#define WMMU_REG_FAULT_VA_LO    0x088u
#define WMMU_REG_FAULT_VA_HI    0x08cu
#define WMMU_REG_FAULT_LEN      0x090u
#define WMMU_REG_FAULT_GEN      0x094u
#define WMMU_REG_FAULT_SOURCE   0x098u
#define WMMU_ENTRY_BASE         0x200u
#define WMMU_ENTRY_STRIDE       0x020u
#define WMMU_ATTR_VALID         UINT64_C(1)
#define WMMU_ATTR_READ          UINT64_C(2)
#define WMMU_ATTR_WRITE         UINT64_C(4)
#define WMMU_ATTR_NODE(n)       ((uint64_t)(n) << 4)
enum wmmu_command { WMMU_START=1, WMMU_HALT=2, WMMU_CHECK=3,
                    WMMU_CLEAR_FAULT=4, WMMU_CLEAR_CFG_ERROR=5 };
enum wmmu_state { WMMU_STOPPED=0, WMMU_CHECKING=1, WMMU_RUNNING=2,
                 WMMU_DRAINING=3, WMMU_FAULT_DRAIN=4, WMMU_FAULT_STOP=5 };
enum wmmu_result { WMMU_OK=0, WMMU_BAD_REQ=1, WMMU_NO_MATCH=2,
                  WMMU_MULTI_HIT=3, WMMU_CROSS_SEG=4, WMMU_PERMISSION=5,
                  WMMU_PA_RANGE=6, WMMU_NODE_ERROR=7, WMMU_CANCELLED=8,
                  WMMU_INTERNAL=9 };
/* Layout descriptor only: use platform ordered 32-bit MMIO accessors, not
 * direct struct assignment or ordinary volatile stores for device ordering. */
struct wmmu_entry { uint64_t va_base, size, pa_base, attr; };
_Static_assert(sizeof(struct wmmu_entry)==32, "entry size");
_Static_assert(offsetof(struct wmmu_entry, attr)==24, "entry attr offset");
#endif
