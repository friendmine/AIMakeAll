"""Run model invariants, differential RTL simulation and C header checks.
Requires Python 3.10+, Icarus Verilog (iverilog/vvp), and clang or cc.
The generated vectors and executables are temporary. No package downloads.
"""
import random
import shutil
import subprocess
import tempfile
from pathlib import Path
from wmmu_model import *

ROOT=Path(__file__).resolve().parent
rng=random.Random(0x574d4d55)

def oracle(es, mask, va, length, op):
    # Independent interval-end formulation (unbounded Python arithmetic).
    if va >> 48 or length == 0 or length > 4096 or op >= 2:
        return (BAD_REQ,0,0,255)
    candidates=[(i,e) for i,e in enumerate(es) if e.valid and e.va <= va < e.va+e.size]
    if not candidates:return (NO_MATCH,0,0,255)
    if len(candidates)>1:return (MULTI_HIT,0,0,255)
    i,e=candidates[0]
    if va+length>e.va+e.size:return (CROSS_SEG,0,0,i)
    if not (e.attr >> (op+1)) & 1:return (PERMISSION,0,0,i)
    pa=e.pa+(va-e.va)
    if e.pa>=LIMIT or pa+length>LIMIT:return (PA_RANGE,0,0,i)
    if not (mask & (1<<e.node)):return (NODE_ERROR,0,0,i)
    return (OK,e.node,pa,i)

vectors=[]
statuses=set()
def add(es,mask,va,length,op):
    expected=oracle(es,mask,va,length,op)
    assert translate(es,mask,va,length,op)==expected
    statuses.add(expected[0]);vectors.append((es,mask,va,length,op,expected))

base=[Entry(0x10000,0x2000,0x40000,7), Entry(0x12000,0x1000,0x80000,0x13)]+[Entry() for _ in range(14)]
assert validate(base,3)==(0,255,255)
for va in [0,0xffff,0x10000,0x11fff,0x12000,0x12fff,0x13000,LIMIT-1,LIMIT]:
    for length in [0,1,2,64,4096,4097]:
        for op in range(4):add(base,3,va,length,op)
overlap=base.copy();overlap[2]=Entry(0x11000,0x1000,0,7)
assert validate(overlap,3)==(CFG_OVERLAP,0,2)
add(overlap,3,0x11000,1,0)
badpa=base.copy();badpa[0]=Entry(0x10000,0x2000,LIMIT-4096,7)
add(badpa,3,0x11fff,1,0)
add(base,1,0x12000,1,0)
full=[Entry(0,LIMIT,0,7)]+[Entry() for _ in range(15)]
assert validate(full,1)==(0,255,255)
add(full,1,LIMIT-1,1,0);add(full,1,LIMIT-1,2,0)
cases=[(Entry(0,4096,0,0x10f),CFG_ENTRY),(Entry(1,4096,0,7),CFG_ALIGN),
       (Entry(LIMIT,4096,0,7),CFG_VRANGE),(Entry(0,4096,LIMIT,7),CFG_PRANGE),
       (Entry(0,4096,0,0x23),CFG_NODE)]
for e,code in cases:assert validate([e]+[Entry() for _ in range(15)],3)[0]==code
assert validate([Entry() for _ in range(16)],3)[0]==CFG_EMPTY

for _ in range(3000):
    es=[]
    for i in range(16):
        va=0x100000*i
        size=rng.choice([4096,8192,65536,0x100000])
        attr=1|rng.choice([2,4,6])|(rng.randrange(4)<<4)
        es.append(Entry(va,size,rng.randrange(0,1<<20)*4096,attr))
    assert validate(es,15)==(0,255,255)
    e=rng.choice(es)
    va=e.va+rng.choice([0,1,e.size-1,e.size,e.size//2])
    length=rng.choice([1,2,16,64,4096,4097,0])
    op=rng.randrange(4)
    add(es,rng.choice([15,3,1]),va,length,op)
assert statuses==set(range(8)),statuses

with tempfile.TemporaryDirectory(prefix='wmmu-check-') as td:
    td=Path(td);vf=td/'vectors.txt'
    with vf.open('w') as f:
        f.write(str(len(vectors))+'\n')
        for es,mask,va,length,op,expected in vectors:
            f.write(' '.join(f'{v:x}' for v in (mask,va,length,op,*expected))+'\n')
            for e in es:f.write(f'{e.va:x} {e.size:x} {e.pa:x} {e.attr:x}\n')
    iv=shutil.which('iverilog');vv=shutil.which('vvp');cc=shutil.which('clang') or shutil.which('cc')
    if not all([iv,vv,cc]):raise SystemExit('Install iverilog/vvp and a C compiler; RTL/C checks not run.')
    subprocess.run([iv,'-g2012','-s','tb_lookup','-o',str(td/'sim'),str(ROOT/'wmmu_lookup.sv'),str(ROOT/'tb_lookup.sv')],check=True)
    subprocess.run([vv,str(td/'sim'),'+vectors='+str(vf)],check=True)
    c=td/'header_check.c';c.write_text('#include "wmmu_regs.h"\nint main(void) { return 0; }\n')
    subprocess.run([cc,'-std=c11','-Wall','-Wextra','-Werror','-fsyntax-only','-I',str(ROOT),str(c)],check=True)
print(f'PASS model / validator / C layout; {len(vectors)} RTL comparisons; seed 0x574d4d55')
