"""WMMU16 v0.1 pure reference functions; no state machine or bus implementation."""
from dataclasses import dataclass

N = 16
LIMIT = 1 << 48
GRANULE = 4096
MAX_REQ = 4096
OK, BAD_REQ, NO_MATCH, MULTI_HIT, CROSS_SEG, PERMISSION, PA_RANGE, NODE_ERROR, CANCELLED, INTERNAL = range(10)
CFG_ENTRY, CFG_ALIGN, CFG_VRANGE, CFG_PRANGE, CFG_NODE, CFG_OVERLAP, CFG_EMPTY = range(1, 8)
ATTR_MASK = 0xF7  # V bit 0, R bit 1, W bit 2, NODE bits 7:4

@dataclass(frozen=True)
class Entry:
    va: int = 0
    size: int = 0
    pa: int = 0
    attr: int = 0

    @property
    def valid(self): return bool(self.attr & 1)
    @property
    def node(self): return (self.attr >> 4) & 15

def validate(entries, node_mask):
    """Return (code, entry, peer); code 0 means success. Ordering is normative."""
    assert len(entries) == N
    active = []
    for i, e in enumerate(entries):
        if not e.valid:
            continue
        active.append(i)
        if e.attr & ~ATTR_MASK or not (e.attr & 6):
            return CFG_ENTRY, i, 255
        if (e.va | e.pa | e.size) & (GRANULE-1):
            return CFG_ALIGN, i, 255
        if not (0 <= e.va < LIMIT and 0 < e.size <= LIMIT and e.va + e.size <= LIMIT):
            return CFG_VRANGE, i, 255
        if not (0 <= e.pa < LIMIT and e.pa + e.size <= LIMIT):
            return CFG_PRANGE, i, 255
        if not (node_mask >> e.node) & 1:
            return CFG_NODE, i, 255
    if not active:
        return CFG_EMPTY, 255, 255
    for i in active:
        for j in active:
            if j <= i: continue
            a, b = entries[i], entries[j]
            if a.va < b.va + b.size and b.va < a.va + a.size:
                return CFG_OVERLAP, i, j
    return 0, 255, 255

def translate(entries, node_mask, va, length, op):
    """Return (status, node, pa, index); op 0=read, 1=write. Pure lookup only."""
    if not (0 <= va < LIMIT and 1 <= length <= MAX_REQ and op in (0, 1)):
        return BAD_REQ, 0, 0, 255
    hits = [i for i, e in enumerate(entries) if e.valid and va >= e.va and va-e.va < e.size]
    if not hits: return NO_MATCH, 0, 0, 255
    if len(hits) != 1: return MULTI_HIT, 0, 0, 255
    i = hits[0]; e = entries[i]; off = va - e.va
    if length > e.size - off: return CROSS_SEG, 0, 0, i
    if not (e.attr & (2 if op == 0 else 4)): return PERMISSION, 0, 0, i
    if not (0 <= e.pa < LIMIT and e.pa+off+length <= LIMIT): return PA_RANGE, 0, 0, i
    if not ((node_mask >> e.node) & 1): return NODE_ERROR, 0, 0, i
    return OK, e.node, e.pa+off, i
